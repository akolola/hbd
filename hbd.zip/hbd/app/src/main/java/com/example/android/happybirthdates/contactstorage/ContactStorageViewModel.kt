package com.example.android.happybirthdates.contactstorage

import androidx.lifecycle.ViewModel

class ContactStorageViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}