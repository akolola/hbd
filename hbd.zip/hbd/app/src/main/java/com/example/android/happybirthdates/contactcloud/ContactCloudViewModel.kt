package com.example.android.happybirthdates.contactcloud

import androidx.lifecycle.ViewModel

class ContactCloudViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}