package com.example.android.happybirthdates.contactbackup

import androidx.lifecycle.ViewModel

class ContactBackupViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}